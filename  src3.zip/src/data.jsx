export const people = [
  {
    id: 1,
    img: "/image/img1.jpg",
    name: "BRIDAL MAKEUP SESSION",
    Duration: "1hr 20mins",
    Price: "$150",
  },
  {
    id: 2,
    img: "/image/img2.jpg",
    name: "BRIDAL MAKEUP SESSION",
    Duration: "1hr 20mins",
    Price: "$150",
  },
  {
    id: 3,
    img: "/image/img3.jpg",
    name: "BRIDAL MAKEUP SESSION",
    Duration: "1hr 20mins",
    Price: "$150",
  },
  {
    id: 4,
    img: "/image/img4.jpg",
    name: "BRIDAL MAKEUP SESSION",
    Duration: "1hr 20mins",
    Price: "$150",
  },
  {
    id: 5,
    img: "/image/img5.jpg",
    name: "BRIDAL MAKEUP SESSION",
    Duration: "1hr 20mins",
    Price: "$150",
  },
];
